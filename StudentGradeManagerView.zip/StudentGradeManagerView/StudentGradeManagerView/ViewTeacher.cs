﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Store;

namespace StudentGradeManagerView
{
    public partial class ViewTeacher : Form
    {
        public ViewTeacher()
        {
            InitializeComponent();
        }



        private void BtnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateTeacher update = new UpdateTeacher();
            update.Show();
            this.Hide();
        }

        private void BtnInput_Click(object sender, EventArgs e)
        {
            InputGrades input = new InputGrades();
            input.Show();
            this.Hide();
        }

        private void BtnViewGrades_Click(object sender, EventArgs e)
        {
            ViewTeacher view = new ViewTeacher();
            view.Show();
            this.Hide();
        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                // Get input from textboxes
                int teacherId = int.Parse(txtTeacher.Text); // Assuming you have a textbox for TeacherID
                string semester = txtSemester.Text; // Assuming you have a textbox for Semester

                string apiUrl = $"https://localhost:44330/api/Teacher/{teacherId}/PerformanceReport?semester={semester}";

                using (var client = new HttpClient())
                {
                    // Send the GET request
                    var response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        // Deserialize the JSON response into a list of objects
                        var jsonResponse = await response.Content.ReadAsStringAsync();
                        var performanceReports = JsonConvert.DeserializeObject<List<PerformanceReport1>>(jsonResponse);

                        // Bind the data to a DataGridView
                        dgvTeacherGrades.DataSource = performanceReports;
                    }
                    else
                    {
                        // Handle error response
                        MessageBox.Show("Failed to fetch performance report. Status code: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdateAcc_Click_1(object sender, EventArgs e)
        {
            UpdateTeacher updateTeacher = new UpdateTeacher();
            updateTeacher.Show();
            this.Hide();
        }

        private void btnCourse_Click_1(object sender, EventArgs e)
        {
            AssignedCourse assignedCourse = new AssignedCourse();
            assignedCourse.Show();
            this.Hide();
        }

        private void btnInput_Click_1(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void btnViewGrades_Click_1(object sender, EventArgs e)
        {
            ViewTeacher viewTeacher = new ViewTeacher();
            viewTeacher.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnCourseAssigned_Click(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse = new AssignedCourse1();
            assignedCourse.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }
    }
}
