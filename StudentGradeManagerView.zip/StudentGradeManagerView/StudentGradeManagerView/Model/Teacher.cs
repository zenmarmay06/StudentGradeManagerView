﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Model
{
    public class Teacher:Person1
    {
        public int TeacherID { get; set; }


        public string Rank { get; set; }

        // Add the AssignedCourses property to hold the assigned courses
        public List<AssignedCourse> AssignedCourse{ get; set; } = new List<AssignedCourse>(); // Default empty list
    }
}
