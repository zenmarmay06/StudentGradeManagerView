﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Model
{
    public class Student:Person1
    {
        public int StudentID { get; set; }
        // public string Position { get; set; }
        public string YearSection { get; set; }
        public List<int> CourseIDs { get; set; } // List of Course IDs

    }
}
