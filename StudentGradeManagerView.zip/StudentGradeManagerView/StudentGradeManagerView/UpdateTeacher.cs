﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;

namespace StudentGradeManagerView
{
    public partial class UpdateTeacher : Form
    {
        public UpdateTeacher()
        {
            InitializeComponent();
        }

       
        private void BtnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateTeacher update = new UpdateTeacher();
            update.Show();
            this.Hide();
        }

        private void BtnInput_Click(object sender, EventArgs e)
        {
            InputGrades input = new InputGrades();
            input.Show();
            this.Hide();
        }

        private void BtnViewGrades_Click(object sender, EventArgs e)
        {
            ViewTeacher view = new ViewTeacher();
            view.Show();
            this.Hide();
        }
        private async Task<List<Teacher>> FetchAllTeachersAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Teachers"); // Replace with your actual API URL
                HttpResponseMessage response = await client.GetAsync("Teachers");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<Teacher>>(jsonString);
                }
                else
                {
                    MessageBox.Show("Failed to fetch teachers.");
                    return new List<Teacher>();
                }
            }
        }

        private async Task<Teacher> FetchTeacherByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Teacher/Teachers");
                try
                {
                    HttpResponseMessage response = await client.GetAsync($"Teachers/{id}");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<Teacher>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Teacher not found or an error occurred.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching teacher: {ex.Message}");
                    return null;
                }
            }
        }

        private async Task<bool> UpdateTeacherAsync(Teacher updatedTeacher)
        {
            try
            {
                // Serialize the updatedTeacher object to JSON
                string json = JsonConvert.SerializeObject(updatedTeacher);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Teacher/Teachers");

                    // Make a PUT request to update the teacher by TeacherID
                    HttpResponseMessage response = await client.PutAsync($"{updatedTeacher.TeacherID}", content);

                    if (response.IsSuccessStatusCode)
                    {
                        return true; // Update was successful
                    }
                    else
                    {
                        // Log response details for debugging
                        string responseContent = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to update teacher.\nStatus Code: {response.StatusCode}\nResponse: {responseContent}");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle and log unexpected errors
                MessageBox.Show($"Error updating teacher: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> DeleteTeacherAsync(int teacherId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Teacher/Teachers");
                    // Send the DELETE request to delete the admin by AdminID
                    HttpResponseMessage response = await client.DeleteAsync($"Teachers/{teacherId}");
                    return response.IsSuccessStatusCode; // Return success or failure based on response
                }
            }
            catch (Exception ex)
            {
                // Show an error message in case of exception
                MessageBox.Show($"Error deleting teacher: {ex.Message}");
                return false;
            }
        }


        private void ClearTeacherFields()
        {
            lblTeacherID.Text = string.Empty;
            txtFullName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtRank.Text = string.Empty;
        }
     

        private async void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate and parse the Teacher ID
                if (!int.TryParse(txtTeacher.Text, out int teacherId))
                {
                    MessageBox.Show("Invalid Teacher ID. Please enter a valid numeric ID.");
                    return;
                }

                // Create an updated Teacher object from the UI fields
                var updatedTeacher = new Teacher
                {
                    TeacherID = teacherId,
                    Name = txtFullName.Text,
                    Email = txtEmail.Text,
                    Password = txtPassword.Text, // Password is entered by the user
                    Rank = txtRank.Text
                };

                // Call the async method to update the Teacher in the API
                bool isUpdated = await UpdateTeacherAsync(updatedTeacher);
                if (isUpdated)
                {
                    MessageBox.Show("Teacher updated successfully.");
                    // Clear the fields after a successful update
                    lblTeacherID.ResetText();
                    txtTeacher.Clear();
                    txtFullName.Clear();
                    txtEmail.Clear();
                    txtPassword.Clear();
                    txtRank.Clear();
                }
                else
                {
                    MessageBox.Show("Failed to update teacher.");
                }
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(lblTeacherID.Text, out int teacherId))
            {
                MessageBox.Show("Invalid Teacher ID.");
                return;
            }

            var confirmResult = MessageBox.Show("Are you sure to delete this teacher?",
                                                 "Confirm Delete",
                                                 MessageBoxButtons.YesNo);

            if (confirmResult == DialogResult.Yes)
            {
                var isDeleted = await DeleteTeacherAsync(teacherId);

                if (isDeleted)
                {
                    MessageBox.Show("Teacher deleted successfully.");
                    ClearTeacherFields(); // Clear the fields
                }
                else
                {
                    MessageBox.Show("Failed to delete teacher.");
                }
            }
        }

        private async void BtnSearch_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtTeacher.Text, out int teacherId))
            {
                var teacher = await FetchTeacherByIdAsync(teacherId); // Fetch teacher by ID
                if (teacher != null)
                {
                    lblTeacherID.Text = teacher.TeacherID.ToString();
                    txtFullName.Text = teacher.Name;
                    txtEmail.Text = teacher.Email;
                    txtPassword.Text = teacher.Password;
                    txtRank.Text = teacher.Rank;
                }
                else
                {
                    MessageBox.Show("Teacher not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Teacher ID.");
            }
        }

        private void BtnUpdateAcc_Click_1(object sender, EventArgs e)
        {
            UpdateTeacher updateTeacher = new UpdateTeacher();
            updateTeacher.Show();
            this.Hide();
        }

        private void BtnCourse_Click_1(object sender, EventArgs e)
        {
            AssignedCourse assignedCourse = new AssignedCourse();
            assignedCourse.Show();
            this.Hide();
        }

        private void BtnInput_Click_1(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnCourseAssigned_Click(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse = new AssignedCourse1();
            assignedCourse.Show();
            this.Hide();
        }

        private void BtnViewGrades_Click_1(object sender, EventArgs e)
        {
            ViewTeacher viewTeacher     = new ViewTeacher();
            viewTeacher.Show();
            this.Hide();
        }
    }
}
