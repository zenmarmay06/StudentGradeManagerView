﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net.Http;
using StudentGradeManagerView.Store;
using System.Drawing.Printing;

namespace StudentGradeManagerView
{
    public partial class ViewStudent : Form
    {
        private PrintDocument printDocument;
        public ViewStudent()
        {
            InitializeComponent();
            printDocument = new PrintDocument();
            printDocument.PrintPage += PrintDocument_PrintPage;
        }

        private void BtnCourse_Click(object sender, EventArgs e)
        {
            StudentForm courselist = new StudentForm();
            courselist.Show();
            this.Hide();
        }

        private void BtnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateStudent update = new UpdateStudent();
            update.Show();
            this.Hide();
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            ViewStudent view = new ViewStudent();
            view.Show();
            this.Hide();
        }

        private async Task<dynamic> FetchPerformanceReportAsync(int studentId, string semester)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Student/Students");

                try
                {
                    // Include the semester as a query parameter
                    string url = $"{studentId}/PerformanceReport?semester={semester}";

                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<dynamic>(jsonString);  // Deserialize into dynamic object
                    }
                    else
                    {
                        string errorContent = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Error fetching performance report: {response.StatusCode}\n{errorContent}");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching performance report: {ex.Message}");
                    return null;
                }
            }
        }


        private async void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                // Get input from textboxes
                int studentId = int.Parse(txtStudent.Text); // Assuming you have a textbox for StudentID
                string semester = txtSemester.Text; // Assuming you have a textbox for Semester

                // Construct the API URL with StudentID and Semester
                string apiUrl = $"https://localhost:44330/api/Student/{studentId}/PerformanceReport?semester={semester}";

                using (var client = new HttpClient())
                {
                    // Send the GET request to the API
                    var response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        // Deserialize the JSON response into a PerformanceReport object
                        var jsonResponse = await response.Content.ReadAsStringAsync();
                        var performanceReport = JsonConvert.DeserializeObject<PerformanceReport>(jsonResponse);

                        // Check if performance data is available
                        if (performanceReport != null && performanceReport.Grades != null && performanceReport.Grades.Any())
                        {
                            // Bind the grades to the DataGridView
                            dgvPerformanceReport.DataSource = performanceReport.Grades;

                            // Store performance data in the Tag property
                            dgvPerformanceReport.Tag = new
                            {
                                StudentName = performanceReport.StudentName,
                                StudentID = performanceReport.StudentID,
                                Semester = performanceReport.Semester
                            };

                            MessageBox.Show($"Performance report for {performanceReport.StudentName} ({performanceReport.StudentID}) loaded successfully.");
                        }
                        else
                        {
                            MessageBox.Show("No performance data found for this student in the specified semester.");
                        }
                    }
                    else
                    {
                        // Handle error response
                        MessageBox.Show($"Failed to fetch performance report. Status code: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnUpdateAcc_Click_1(object sender, EventArgs e)
        {
            UpdateStudent updateStudent = new UpdateStudent();
            updateStudent.Show();
            this.Hide();
        }

        private void btnCourse_Click_1(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm();
            studentForm.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            try
            {
                // Get graphics object and define layout
                Graphics graphics = e.Graphics;
                Font font = new Font("Arial", 12);
                Font boldFont = new Font("Arial", 12, FontStyle.Bold);
                Font headerFont = new Font("Arial", 18, FontStyle.Bold); // Font for the header
                float fontHeight = font.GetHeight();
                int startY = 10;
                int offsetY = 0;

                // Get page width and calculate horizontal center
                int pageWidth = e.MarginBounds.Width;
                int reportWidth = 600; // Define the width of the report content (can be adjusted based on your layout)
                int startX = (pageWidth - reportWidth) / 2; // This will center the report horizontally

                // Retrieve performance data from the Tag property
                if (dgvPerformanceReport.Tag == null)
                {
                    MessageBox.Show("No performance data found for printing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                dynamic reportInfo = dgvPerformanceReport.Tag;
                string studentName = reportInfo.StudentName ?? "N/A";
                int studentId = reportInfo.StudentID ?? 0;
                string semester = reportInfo.Semester ?? "N/A";

                // Center the "Performance Report" header
                string reportTitle = "Performance Report";
                SizeF headerSize = graphics.MeasureString(reportTitle, headerFont);
                float headerX = (pageWidth - headerSize.Width) / 2; // Calculate the center of the page

                // Header Information
                graphics.DrawString(reportTitle, headerFont, Brushes.Black, headerX, startY + offsetY);
                offsetY += (int)headerSize.Height + 20; // Adjust for header size

                graphics.DrawString($"Student Name: {studentName}", font, Brushes.Black, startX, startY + offsetY);
                offsetY += (int)fontHeight + 5;

                graphics.DrawString($"Student ID: {studentId}", font, Brushes.Black, startX, startY + offsetY);
                offsetY += (int)fontHeight + 5;

                graphics.DrawString($"Semester: {semester}", font, Brushes.Black, startX, startY + offsetY);
                offsetY += (int)fontHeight + 20;

                // Column Headers with precise positions
                int colCourseX = startX;
                int colMidtermX = startX + 150;
                int colFinalX = startX + 300;
                int colAverageX = startX + 450;

                graphics.DrawString("Course", boldFont, Brushes.Black, colCourseX, startY + offsetY);
                graphics.DrawString("Midterm", boldFont, Brushes.Black, colMidtermX, startY + offsetY);
                graphics.DrawString("Final", boldFont, Brushes.Black, colFinalX, startY + offsetY);
                graphics.DrawString("Average", boldFont, Brushes.Black, colAverageX, startY + offsetY);
                offsetY += (int)fontHeight + 10;

                // Data rows from DataGridView
                foreach (DataGridViewRow row in dgvPerformanceReport.Rows)
                {
                    if (row.IsNewRow) continue;

                    string course = row.Cells["CourseName"].Value?.ToString() ?? "N/A";
                    string midterm = row.Cells["MidtermGrade"].Value?.ToString() ?? "N/A";
                    string final = row.Cells["FinalGrade"].Value?.ToString() ?? "N/A";
                    string average = row.Cells["FinalAverage"].Value?.ToString() ?? "N/A";

                    graphics.DrawString(course, font, Brushes.Black, colCourseX, startY + offsetY);
                    graphics.DrawString(midterm, font, Brushes.Black, colMidtermX, startY + offsetY);
                    graphics.DrawString(final, font, Brushes.Black, colFinalX, startY + offsetY);
                    graphics.DrawString(average, font, Brushes.Black, colAverageX, startY + offsetY);

                    offsetY += (int)fontHeight + 5;

                    // Handle page overflow
                    if (offsetY + fontHeight > e.MarginBounds.Height)
                    {
                        e.HasMorePages = true;
                        return;
                    }
                }

                // Footer
                offsetY += 20;
                e.HasMorePages = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during printing: {ex.Message}");
            }

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if the Tag property contains performance data
                if (dgvPerformanceReport.Tag == null)
                {
                    MessageBox.Show("No performance data available for printing. Please search for a report first.", "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Configure and show the print preview dialog
                PrintPreviewDialog previewDialog = new PrintPreviewDialog
                {
                    Document = printDocument // Ensure this is linked to your PrintDocument
                };

                previewDialog.ShowDialog();
                UpdateStudent updateStudent = new UpdateStudent();
                updateStudent.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                // Handle exceptions during print preview
                MessageBox.Show($"Error during print preview: {ex.Message}");
            }
        }
    }
}
