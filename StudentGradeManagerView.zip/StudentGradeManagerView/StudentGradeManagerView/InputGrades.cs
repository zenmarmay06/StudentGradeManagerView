﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Store;

namespace StudentGradeManagerView
{
    public partial class InputGrades : Form
    {
        public InputGrades()
        {
            InitializeComponent();
        }

       
        private void btnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateTeacher update = new UpdateTeacher();
            update.Show();
            this.Hide();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            InputGrades input = new InputGrades();
            input.Show();
            this.Hide();
        }

        private void btnViewGrades_Click(object sender, EventArgs e)
        {
            ViewTeacher view = new ViewTeacher();
            view.Show();
            this.Hide();
        }

        private async void btnInput_Click(object sender, EventArgs e)
        {
            try
            {
                // Create the request model and populate it with data from the form
                var inputGradesRequest = new UpdateGradeRequest
                {
                    TeacherID = int.Parse(txtTeacher.Text), // Assuming you have a textbox for Teacher ID
                    StudentID = int.Parse(txtStudentID.Text), // Assuming you have a textbox for Student ID
                    CourseID = int.Parse(txtCourseID.Text), // Assuming you have a textbox for Course ID
                    Semester = txtSemester.Text, // Assuming you have a textbox for Semester
                    MidtermGrade = double.Parse(txtMidterm.Text), // Assuming you have a textbox for Midterm Grade
                    FinalGrade = double.Parse(txtFinal.Text) // Assuming you have a textbox for Final Grade
                };

                string apiUrl = $"https://localhost:44330/api/Teacher/{inputGradesRequest.TeacherID}/InputGrades";

                using (var client = new HttpClient())
                {
                    // Set the content of the request (JSON)
                    var content = new StringContent(JsonConvert.SerializeObject(inputGradesRequest), Encoding.UTF8, "application/json");

                    // Send the POST request
                    var response = await client.PostAsync(apiUrl, content);

                    // Handle the response
                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Grades inputted  successfully.");
                        txtTeacher.Clear();
                        txtStudentID.Clear();
                        txtCourseID.Clear();
                        txtFinal.Clear();
                        txtMidterm.Clear();
                        txtSemester.Clear();

                    }
                    else
                    {
                        // If the response is not successful, show an error message
                        MessageBox.Show("Failed to input grades. Status code: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                // Catch any exception and show the error message
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        public async Task GetAssignedCourses(int teacherId)
        {
            string apiUrl = "https://localhost:44330/api/Teacher/" + teacherId;
            using (var client = new HttpClient())
            {
                try
                {
                    // Send GET request and get the response
                    var response = await client.GetAsync(apiUrl);

                    // Log the status code for debugging
                    MessageBox.Show("Successfully fetch.");

                    // If status code is not OK (200), display an error message
                    if (!response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Failed to fetch data. Status code: " + response.StatusCode);
                        return;
                    }

                    // Read the response content as string
                    var responseContent = await response.Content.ReadAsStringAsync();

                    // Log the raw response content for debugging
                    //MessageBox.Show("Raw API Response: " + responseContent);

                    // Deserialize the JSON response to a List of CourseAssignments (or directly to your model)
                    var courses = JsonConvert.DeserializeObject<List<CourseAssignment1>>(responseContent);

                    // Check if the courses list is null or empty
                    if (courses == null || courses.Count == 0)
                    {
                        MessageBox.Show("No courses found for this teacher.");
                        return;
                    }

                    // Bind the deserialized data to the DataGridView
                    dgvTeacherAcc.DataSource = courses; // Directly bind the courses list
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("Error fetching data: " + ex.Message);
                }

            }
        }
        private async void button1_Click(object sender, EventArgs e)
        {
            int teacherId = int.Parse(txtTeacher.Text); // Assuming txtTeacherId is where the Teacher ID is entered
            await GetAssignedCourses(teacherId);
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Create the request model and populate it with data from the form
                var updateGradesRequest = new UpdateGradeRequest
                {
                    TeacherID = int.Parse(txtTeacher.Text), // Teacher ID
                    StudentID = int.Parse(txtStudentID.Text), // Student ID
                    CourseID = int.Parse(txtCourseID.Text), // Course ID
                    Semester = txtSemester.Text, // Semester
                    MidtermGrade = double.Parse(txtMidterm.Text), // Midterm Grade
                    FinalGrade = double.Parse(txtFinal.Text) // Final Grade
                };

                // Define the API endpoint for updating grades
                string apiUrl = $"https://localhost:44330/api/Teacher/{updateGradesRequest.TeacherID}/UpdateGrades";

                using (var client = new HttpClient())
                {
                    // Set the content of the request (JSON)
                    var content = new StringContent(JsonConvert.SerializeObject(updateGradesRequest), Encoding.UTF8, "application/json");

                    // Send the PUT request for updating grades
                    var response = await client.PutAsync(apiUrl, content);

                    // Handle the response
                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Grades updated successfully.");
                        txtTeacher.Clear();
                        txtStudentID.Clear();
                        txtCourseID.Clear();
                        txtFinal.Clear();
                        txtMidterm.Clear();
                        txtSemester.Clear();
                    }
                    else
                    {
                        // If the response is not successful, show an error message
                        MessageBox.Show("Failed to update grades. Status code: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                // Catch any exception and show the error message
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }
    }
}
