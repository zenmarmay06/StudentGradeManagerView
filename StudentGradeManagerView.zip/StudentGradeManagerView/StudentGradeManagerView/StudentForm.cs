﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http.Formatting;
using Newtonsoft.Json;



namespace StudentGradeManagerView
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
            
        }
        private async Task<List<dynamic>> FetchAssignedCoursesAsync(int studentId)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Student/Students");

                try
                {
                    HttpResponseMessage response = await client.GetAsync($"{studentId}/AssignedCourses");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<List<dynamic>>(jsonString);
                    }
                    else
                    {
                        string errorContent = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Error fetching assigned courses: {response.StatusCode}\n{errorContent}");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching assigned courses: {ex.Message}");
                    return null;
                }
            }
        }


        


        private async void btnSearch_Click(object sender, EventArgs e)
        {
            // Validate and parse Student ID input
            if (!int.TryParse(txtStudentID.Text, out int studentId))
            {
                MessageBox.Show("Invalid Student ID. Please enter a valid numeric ID.");
                return;
            }

            try
            {
                var assignedCourses = await FetchAssignedCoursesAsync(studentId);

                if (assignedCourses != null && assignedCourses.Count > 0)
                {
                    dgvAssignedCourses.DataSource = null; // Clear existing data
                    dgvAssignedCourses.DataSource = assignedCourses;

                    MessageBox.Show("Assigned courses loaded successfully.");
                }
                else
                {
                    MessageBox.Show("No courses assigned to this student.");
                }
            }
            catch (Exception ex)
            {
                
            }
        }

        private void btnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateStudent updateStudent = new UpdateStudent();
            updateStudent.Show();
            this.Hide();
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm();
            studentForm.Show();
            this.Hide();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            ViewStudent viewStudent = new ViewStudent();
            viewStudent.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }
    }
}
