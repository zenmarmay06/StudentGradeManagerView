﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using StudentGradeManagerView.Store;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;


namespace StudentGradeManagerView
{
    public partial class CourseList : Form
    {
       
        public CourseList()
        {
            InitializeComponent();
        }

        // Fetch and display all courses in DataGridView
        private async Task<List<Course>> FetchAllCoursesAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Courses"); // Replace with your actual API URL
                HttpResponseMessage response = await client.GetAsync("Courses");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<Course>>(jsonString);
                }
                else
                {
                    MessageBox.Show("Failed to fetch courses.");
                    return new List<Course>();
                }
            }
        }
        private async Task<Course> FetchCourseByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Courses"); // Replace with your actual API URL
                HttpResponseMessage response = await client.GetAsync($"Courses/{id}");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<Course>(jsonString);
                }
                else
                {
                    MessageBox.Show("Teache not found.");
                    return null;
                }
            }
        }

        private async Task<bool> UpdateCourseAsync(Course updatedCourse)
        {
            try
            {
                string json = JsonConvert.SerializeObject(updatedCourse);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Courses");
                    HttpResponseMessage response = await client.PutAsync($"Courses/{updatedCourse.CourseID}", content);

                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating course: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> DeleteCourseAsync(int courseId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Courses");
                    HttpResponseMessage response = await client.DeleteAsync($"Courses/{courseId}");

                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting course: {ex.Message}");
                return false;
            }
        }

       
        private void ClearCourseFields()
        {
            txtCourseName.Text = string.Empty;
            
            
        }


        private async Task RefreshCourseListAsync()
        {
            dgvCourse.DataSource = null;
            var courses = await FetchAllCoursesAsync();

            if (courses.Any())
            {
                dgvCourse.DataSource = courses;
            }
            else
            {
                MessageBox.Show("No courses found.");
            }
        }

        


      

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtCourse.Text, out int courseId))
            {
                var course = await FetchCourseByIdAsync(courseId);
                if (course != null)
                {
                    txtCourseName.Text = course.CourseName;
                    txtCourse.Clear();
                    
                }
                else
                {
                    MessageBox.Show("Course not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Course ID.");
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate input fields
                if (string.IsNullOrWhiteSpace(txtCourseName.Text) ||
                    !int.TryParse(txtCourse.Text, out int courseId))
                {
                    MessageBox.Show("Please provide a valid Course ID and Course Name.");
                    return;
                }

                // Collect course details to update
                var updatedCourse = new Course
                {
                    CourseID = courseId, // Assuming CourseId is a property of Course
                    CourseName = txtCourseName.Text,
                };

                string apiUrl = $"https://localhost:44330/api/Admin/Courses/{courseId}";

                using (var client = new HttpClient())
                {
                    var jsonContent = JsonConvert.SerializeObject(updatedCourse);
                    var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                    var response = await client.PutAsync(apiUrl, content);

                    if (response.IsSuccessStatusCode)
                    {
                        var jsonResponse = await response.Content.ReadAsStringAsync();
                        var updatedCourses = JsonConvert.DeserializeObject<List<Course>>(jsonResponse);

                        dgvCourse.DataSource = updatedCourses; // Update the DataGridView
                        MessageBox.Show("Course updated successfully.");
                        txtCourseName.Clear();
                        await RefreshCourseListAsync();
                    }
                    else
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to update course. Status code: {response.StatusCode}. Response: {errorResponse}");
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error: " + ex.Message);
                MessageBox.Show("Course updated successfully.");
                await RefreshCourseListAsync();
            }

        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtCourse.Text, out int courseId))
            {
                MessageBox.Show("Invalid Course ID.");
                return;
            }

            var confirmResult = MessageBox.Show("Are you sure to delete this course?",
                                                 "Confirm Delete",
                                                 MessageBoxButtons.YesNo);

            if (confirmResult == DialogResult.Yes)
            {
                var isDeleted = await DeleteCourseAsync(courseId);

                if (isDeleted)
                {
                    MessageBox.Show("Course deleted successfully.");
                    await RefreshCourseListAsync(); // Refresh the DataGridView
                    ClearCourseFields(); // Clear the fields
                }
                else
                {
                    MessageBox.Show("Failed to delete course.");
                }
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate input fields
                if (string.IsNullOrWhiteSpace(txtCourseName.Text))
                    
                {
                    MessageBox.Show("Please fill in all fields.");
                    return;
                }

                // Collect course details from input fields
                var courses = new List<Course>
        {
            new Course
            {
                CourseName = txtCourseName.Text,
                
            }
        };

                string apiUrl = "https://localhost:44330/api/Admin/Courses";

                using (var client = new HttpClient())
                {
                    var jsonContent = JsonConvert.SerializeObject(courses);
                    var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                    var response = await client.PostAsync(apiUrl, content);

                    if (response.IsSuccessStatusCode)
                    {
                        var jsonResponse = await response.Content.ReadAsStringAsync();
                        var addedCourses = JsonConvert.DeserializeObject<List<Course>>(jsonResponse);

                        dgvCourse.DataSource = addedCourses;
                        MessageBox.Show("Courses added successfully.");
                        await RefreshCourseListAsync();
                    }
                    else
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to add courses. Status code: {response.StatusCode}. Response: {errorResponse}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private async void btnCourseList_Click(object sender, EventArgs e)
        {
            dgvCourse.DataSource = null;
            var courses = await FetchAllCoursesAsync();

            if (courses.Any())
            {
                dgvCourse.DataSource = courses;
            }
            else
            {
                MessageBox.Show("No courses found.");
            }
        }

        

        private void btnUpdateAcc_Click_1(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            adminForm.Show();
            this.Hide();
        }

        private void btnViewGrades_Click_1(object sender, EventArgs e)
        {

        }

        private void btnInput_Click_1(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnAssignedStudent_Click_1(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse1 = new AssignedCourse1();
            assignedCourse1.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UpdateTeacher updateTeacher = new UpdateTeacher();
            updateTeacher.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            UpdateStudent updateStudent = new UpdateStudent();
            updateStudent.Show();
            this.Hide();
        }
    }
}
