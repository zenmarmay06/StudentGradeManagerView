﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Store;

namespace StudentGradeManagerView
{
    public partial class AssignedCourse1 : Form
    {
        public AssignedCourse1()
        {
            InitializeComponent();
        }
        private async Task<List<CourseAssignment>> FetchAllCourseAssignmentsAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/GetAllCourseAssignments");
                HttpResponseMessage response = await client.GetAsync("GetAllCourseAssignments");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<CourseAssignment>>(jsonString);
                }
                else
                {
                    MessageBox.Show("Failed to fetch course assignments.");
                    return new List<CourseAssignment>();
                }
            }
        }


         

        private async Task<bool> UpdateStudentCourseAssignmentAsync(int studentId, int courseId, int teacherId, string newSemester)
        {
            try
            {
                // Create the request object with the new semester
                var request = new
                {
                    StudentId = studentId,
                    CourseId = courseId,
                    TeacherId = teacherId,
                    NewSemester = newSemester
                };

                string json = JsonConvert.SerializeObject(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/GetAllCourseAssignments");
                    HttpResponseMessage response = await client.PutAsync("UpdateStudentCourseAssignment", content);

                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating course assignment: {ex.Message}");
                return false;
            }
        }


        private async Task<bool> RemoveStudentFromCourseAsync(int courseId, int studentId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/GetAllCourseAssignments");
                    HttpResponseMessage response = await client.DeleteAsync($"RemoveStudentFromCourse/{courseId}?studentId={studentId}");

                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error removing student from course: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> AddCourseToStudentAsync(int studentId, int courseId, int teacherId, string semester, string yearSection)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/GetAllCourseAssignments"); // Replace with your API URL

                // Prepare the POST request content
                var postData = new Dictionary<string, string>
        {
            { "studentId", studentId.ToString() },
            { "courseId", courseId.ToString() },
            { "teacherId", teacherId.ToString() },
            { "semester", semester },
            { "yearSection", yearSection }
        };
                var content = new FormUrlEncodedContent(postData);

                // Make the POST request to the API
                HttpResponseMessage response = await client.PostAsync("AssignCourseToStudent", content);

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Failed to add course to student: " + response.ReasonPhrase);
                    return false;
                }
            }
        }




        private async Task RefreshCourseListAsync()
        {
            dgvCourseAss.DataSource = null; // Clear previous data
            var courses = await FetchAllCourseAssignmentsAsync();

            if (courses.Any())
            {
                dgvCourseAss.DataSource = courses;

                // Optionally, check column names and set headers if necessary
                dgvCourseAss.Columns["CourseID"].HeaderText = "Course ID";
                dgvCourseAss.Columns["TeacherID"].HeaderText = "Teacher ID";
                dgvCourseAss.Columns["Semester"].HeaderText = "Semester";
                dgvCourseAss.Columns["StudentID"].HeaderText = "Student ID";
                
            }
            else
            {
                MessageBox.Show("No courses found.");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (!int.TryParse(txtCourseID.Text, out int courseId) ||
                    !int.TryParse(txtStudentID.Text, out int studentId))
                {
                    MessageBox.Show("Please enter valid Course ID and Student ID.");
                    return;
                }

                // Prepare API endpoint URL with parameters
                var apiUrl = $"https://localhost:44330/api/Admin/RemoveStudentFromCourse/{courseId}?studentId={studentId}";

                using (var client = new HttpClient())
                {
                    // Send DELETE request to the API
                    var response = await client.DeleteAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Student removed from course successfully.");
                    }
                    else
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to remove student from course. Status code: {response.StatusCode}. Response: {errorResponse}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (!int.TryParse(txtStudentID.Text, out int studentId) ||
                    !int.TryParse(txtCourseID.Text, out int courseId) ||
                    !int.TryParse(txtTeacherID.Text, out int teacherId) ||
                    string.IsNullOrWhiteSpace(txtSemester.Text))
                {
                    MessageBox.Show("Please fill in all fields correctly.");
                    return;
                }

                // Prepare API endpoint and query parameters
                var apiUrl = "https://localhost:44330/api/Admin/UpdateStudentCourseAssignment";
                var queryParams = $"?studentId={studentId}&courseId={courseId}&teacherId={teacherId}&newSemester={txtSemester.Text}";

                using (var client = new HttpClient())
                {
                    // Send a PUT request to the API
                    var response = await client.PutAsync(apiUrl + queryParams, null);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Course assignment updated successfully.");
                    }
                    else
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to update course assignment. Status code: {response.StatusCode}. Response: {errorResponse}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private async void btnCourseAss_Click(object sender, EventArgs e)
        {
            // Fetch the course assignments
            dgvCourseAss.DataSource = null;
            var courseAssignments = await FetchAllCourseAssignmentsAsync();

            if (courseAssignments.Any())
            {
                // Assuming you have a DataGridView named dgvCourseAssignments
                dgvCourseAss.DataSource = courseAssignments; // Directly set the data source
            }
            else
            {
                MessageBox.Show("No course assignments available.");
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (!int.TryParse(txtStudentID.Text, out int studentId) ||
                    !int.TryParse(txtCourseID.Text, out int courseId) ||
                    !int.TryParse(txtTeacherID.Text, out int teacherId) ||
                    string.IsNullOrWhiteSpace(txtSemester.Text) ||
                    string.IsNullOrWhiteSpace(txtYearSection.Text))
                {
                    MessageBox.Show("Please fill in all fields correctly.");
                    return;
                }

                // Prepare data for the API
                var apiUrl = "https://localhost:44330/api/Admin/AssignCourseToStudent";
                var queryParams = $"?studentId={studentId}&courseId={courseId}&teacherId={teacherId}&semester={txtSemester.Text}&yearSection={txtYearSection.Text}";

                using (var client = new HttpClient())
                {
                    // Make the POST request
                    var response = await client.PostAsync(apiUrl + queryParams, null);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Course assigned to student successfully.");
                    }
                    else
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to assign course. Status code: {response.StatusCode}. Response: {errorResponse}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        
        

        private void btnUpdateAcc_Click_1(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            adminForm.Show();
            this.Hide();
        }

        

        private void btnInput_Click_1(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnAssignedStudent_Click_1(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse1 = new AssignedCourse1();
            assignedCourse1.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UpdateTeacher updateTeacher = new UpdateTeacher();
            updateTeacher.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            UpdateStudent updateStudent = new UpdateStudent();
            updateStudent.Show();
            this.Hide();
        }
    }
}
