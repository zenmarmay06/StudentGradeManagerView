﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StudentGradeManagerView.Model;
using Newtonsoft.Json;


namespace StudentGradeManagerView
{
    public partial class CreateAdmin : Form
    {
        public CreateAdmin()
        {
            InitializeComponent();
        }

        private async Task<bool> RegisterAdminAsync(Admin admin)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Login/");

                try
                {
                    // Send POST request to register admin
                    HttpResponseMessage response = await client.PostAsJsonAsync("register/admin", admin);

                    if (response.IsSuccessStatusCode)
                    {
                        // Deserialize response content using JsonConvert
                        string jsonString = await response.Content.ReadAsStringAsync();
                        var result = JsonConvert.DeserializeObject<dynamic>(jsonString);
                        MessageBox.Show($"Admin account created successfully! ");
                        return true;
                    }
                    else
                    {
                        var errorMessage = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Error: {errorMessage}");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                    return false;
                }
            }
        }


        private async void btnAdd_Click(object sender, EventArgs e)
        {
            // Collect data from the form (example: TextBoxes)
            var admin = new Admin
            {
                Name = txtFullName.Text,
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                Position = txtPosition.Text,
                Role = "admin"  // Set the role (or you can take this from a dropdown, if applicable)
            };

            // Validate fields
            if (string.IsNullOrEmpty(admin.Name) || string.IsNullOrEmpty(admin.Email) ||
                string.IsNullOrEmpty(admin.Password))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            // Call the RegisterAdminAsync method
            bool success = await RegisterAdminAsync(admin);

            if (success)
            {
                // You can clear the form or navigate away after successful registration
                txtFullName.Clear();
                txtEmail.Clear();
                txtPassword.Clear();
                txtPosition.Clear();
                LoginAdmin loginAdmin = new LoginAdmin();
                loginAdmin.Show();
                this.Hide();
            }
        }

        private void CreateAdmin_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShow.Checked)
            {
                txtPassword.PasswordChar = '\0'; // Show the actual password
            }
            else
            {
                txtPassword.PasswordChar = '*';  // Hide the password as '*'
            }
        }
    }
}
