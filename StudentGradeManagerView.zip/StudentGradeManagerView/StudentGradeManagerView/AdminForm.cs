﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;


namespace StudentGradeManagerView
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }
        // Fetch All Teachers
        private async Task<List<Teacher>> FetchAllTeachersAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Teachers");
                try
                {
                    HttpResponseMessage response = await client.GetAsync("Teachers");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<List<Teacher>>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Error fetching teachers.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching teachers: {ex.Message}");
                    return null;
                }
            }
        }

        // Fetch All Students

        private async Task<List<Student>> FetchAllStudentsAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Students");
                try
                {
                    HttpResponseMessage response = await client.GetAsync("Students");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<List<Student>>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Error fetching students.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching students: {ex.Message}");
                    return null;
                }
            }
        }
        // Populate DataGridView with Teachers
        private void PopulateTeachersList(List<Teacher> teachers)
        {
            dgvList.DataSource = null;  // Clear existing data
            dgvList.DataSource = teachers;  // Bind new data to DataGridView
        }

        // Populate DataGridView with Students
        private void PopulateStudentsList(List<Student> students)
        {
            dgvList.DataSource = null;
            dgvList.DataSource = students;
        }

        // Populate DataGridView with Admins
        private void PopulateAdminsList(List<Admin> admins)
        {
            dgvList.DataSource = null;
            dgvList.DataSource = admins;
        }

        // Fetch All Admins
        private async Task<List<Admin>> FetchAllAdminsAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Admins");
                try
                {
                    HttpResponseMessage response = await client.GetAsync("Admins");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<List<Admin>>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Error fetching admins.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching admins: {ex.Message}");
                    return null;
                }
            }
        }

        // Fetch Teacher by ID
        private async Task<Teacher> FetchTeacherByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Teachers");
                try
                {
                    HttpResponseMessage response = await client.GetAsync($"Teachers/{id}");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<Teacher>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Teacher not found or an error occurred.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching teacher: {ex.Message}");
                    return null;
                }
            }
        }

        // Fetch Student by ID
        private async Task<Student> FetchStudentByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Students");
                try
                {
                    HttpResponseMessage response = await client.GetAsync($"Students/{id}");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<Student>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Student not found or an error occurred.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching student: {ex.Message}");
                    return null;
                }
            }
        }

        // Fetch Admin by ID (For reference; similar to fetching Teacher and Student)
        private async Task<Admin> FetchAdminByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Admins");
                try
                {
                    HttpResponseMessage response = await client.GetAsync($"Admins/{id}");

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonString = await response.Content.ReadAsStringAsync();
                        return JsonConvert.DeserializeObject<Admin>(jsonString);
                    }
                    else
                    {
                        MessageBox.Show("Admin not found or an error occurred.");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching admin: {ex.Message}");
                    return null;
                }
            }
        }

        // Update Teacher
        private async Task<bool> UpdateTeacherAsync(Teacher updatedTeacher)
        {
            try
            {
                // Serialize the updatedAdmin object to JSON
                string json = JsonConvert.SerializeObject(updatedTeacher);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Teachers");
                    // Make a PUT request to update the admin by AdminID
                    HttpResponseMessage response = await client.PutAsync($"Teachers/{updatedTeacher.TeacherID}", content);
                    return response.IsSuccessStatusCode; // Return success or failure based on response
                }
            }
            catch (Exception ex)
            {
                // Show an error message in case of exception
                MessageBox.Show($"Error updating teacher: {ex.Message}");
                return false;
            }
        }

        // Update Student
        private async Task<bool> UpdateStudentAsync(Student updatedStudent)
        {
            try
            {
                // Serialize the updatedAdmin object to JSON
                string json = JsonConvert.SerializeObject(updatedStudent);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Students");
                    // Make a PUT request to update the admin by AdminID
                    HttpResponseMessage response = await client.PutAsync($"Students/{updatedStudent.StudentID}", content);
                    return response.IsSuccessStatusCode; // Return success or failure based on response
                }
            }
            catch (Exception ex)
            {
                // Show an error message in case of exception
                MessageBox.Show($"Error updating student: {ex.Message}");
                return false;
            }
        }

        // Update Admin
        private async Task<bool> UpdateAdminAsync(Admin updatedAdmin)
        {
            try
            {
                // Serialize the updatedAdmin object to JSON
                string json = JsonConvert.SerializeObject(updatedAdmin);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Admins");
                    // Make a PUT request to update the admin by AdminID
                    HttpResponseMessage response = await client.PutAsync($"Admins/{updatedAdmin.AdminID}", content);
                    return response.IsSuccessStatusCode; // Return success or failure based on response
                }
            }
            catch (Exception ex)
            {
                // Show an error message in case of exception
                MessageBox.Show($"Error updating admin: {ex.Message}");
                return false;
            }
        }


        // Delete Teacher
        private async Task<bool> DeleteTeacherAsync(int teacherId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Teachers");
                    HttpResponseMessage response = await client.DeleteAsync($"Teachers/{teacherId}");
                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting teacher: {ex.Message}");
                return false;
            }
        }

        // Delete Student
        private async Task<bool> DeleteStudentAsync(int studentId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Students");
                    HttpResponseMessage response = await client.DeleteAsync($"Students/{studentId}");
                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting student: {ex.Message}");
                return false;
            }
        }

        // Delete Admin
        private async Task<bool> DeleteAdminAsync(int adminId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Admin/Admins");
                    // Send the DELETE request to delete the admin by AdminID
                    HttpResponseMessage response = await client.DeleteAsync($"Admins/{adminId}");
                    return response.IsSuccessStatusCode; // Return success or failure based on response
                }
            }
            catch (Exception ex)
            {
                // Show an error message in case of exception
                MessageBox.Show($"Error deleting admin: {ex.Message}");
                return false;
            }
        }

        // Clear Fields
        private void ClearFields()
        {
            txtID.Clear();
            txtFullName.Clear();
            txtEmail.Clear();
            txtPassword.Clear();
            txtPosition.Clear();
        }


        private async void BtnUpdate_Click(object sender, EventArgs e)
        {


            if (string.IsNullOrWhiteSpace(txtTeacher.Text))
            {
                MessageBox.Show("Please enter a valid ID.");
                return;
            }

            // Check if ID is for Teacher, Student, or Admin (based on prefix 'T', 'S', 'A')

            try
            {
                if (txtTeacher.Text.StartsWith("T")) // Teacher ID (assuming starts with 'T')
                {
                    int teacherId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'T' prefix
                    var updatedTeacher = new Teacher
                    {
                        TeacherID = teacherId,
                        Name = txtFullName.Text,
                        Email = txtEmail.Text,
                        Password = txtPassword.Text, // Password is entered by the user
                        Rank = txtPosition.Text
                    };

                    // Call the async method to update the Teacher in the API
                    bool isUpdated = await UpdateTeacherAsync(updatedTeacher);
                    if (isUpdated)
                    {
                        MessageBox.Show("Teacher updated successfully.");
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update teacher.");
                    }
                }
                else if (txtTeacher.Text.StartsWith("S")) // Student ID (assuming starts with 'S')
                {
                    int studentId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'S' prefix
                    var updatedStudent = new Student
                    {
                        StudentID = studentId,
                        Name = txtFullName.Text,
                        Email = txtEmail.Text,
                        Password = txtPassword.Text, // Password is entered by the user
                        YearSection = txtPosition.Text
                    };

                    // Call the async method to update the Teacher in the API
                    bool isUpdated = await UpdateStudentAsync(updatedStudent);
                    if (isUpdated)
                    {
                        MessageBox.Show("Student updated successfully.");
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update student.");
                    }
                }
                else if (txtTeacher.Text.StartsWith("A")) // Admin ID (assuming starts with 'A')
                {
                    int adminId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'A' prefix
                    var updatedAdmin = new Admin
                    {
                        AdminID = adminId,
                        Name = txtFullName.Text,
                        Email = txtEmail.Text,
                        Password = txtPassword.Text
                    };

                    bool isUpdated = await UpdateAdminAsync(updatedAdmin);
                    if (isUpdated)
                    {
                        MessageBox.Show("Admin updated successfully.");
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update admin.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid ID format.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating: {ex.Message}");
            }

        }
            
        

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTeacher.Text))
            {
                MessageBox.Show("Please enter a valid ID.");
                return;
            }

            // Search based on ID prefix (Teacher, Student, Admin)
            if (txtTeacher.Text.StartsWith("T"))
            {
                var teacher = await FetchTeacherByIdAsync(int.Parse(txtTeacher.Text.Substring(1)));  // Remove 'T' prefix
                if (teacher != null)
                {
                    txtFullName.Text = teacher.Name;
                    txtEmail.Text = teacher.Email;
                    txtPassword.Text = teacher.Password;
                    txtPosition.Text = teacher.Rank;

                }
                else
                {
                    MessageBox.Show("Teacher not found.");
                }
            }
            else if (txtTeacher.Text.StartsWith("S"))
            {
                var student = await FetchStudentByIdAsync(int.Parse(txtTeacher.Text.Substring(1)));  // Remove 'S' prefix
                if (student != null)
                {
                    txtFullName.Text = student.Name;
                    txtEmail.Text = student.Email;
                    txtPassword.Text = student.Password;
                    txtPosition.Text = student.YearSection;
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
            }
            else if (txtTeacher.Text.StartsWith("A"))
            {
                var admin = await FetchAdminByIdAsync(int.Parse(txtTeacher.Text.Substring(1)));  // Remove 'A' prefix
                if (admin != null)
                {
                    txtFullName.Text = admin.Name;
                    txtEmail.Text = admin.Email;
                    txtPassword.Text = admin.Password;
                }
                else
                {
                    MessageBox.Show("Admin not found.");
                }
            }
            else
            {
                MessageBox.Show("Invalid ID format.");
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTeacher.Text))
            {
                MessageBox.Show("Please enter a valid ID.");
                return;
            }

            // Confirm deletion with the user
            var confirmResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo);

            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    if (txtTeacher.Text.StartsWith("T")) // Teacher ID (assuming starts with 'T')
                    {
                        int teacherId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'T' prefix
                        bool isDeleted = await DeleteTeacherAsync(teacherId);
                        if (isDeleted)
                        {
                            MessageBox.Show("Teacher deleted successfully.");
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete teacher.");
                        }
                    }
                    else if (txtTeacher.Text.StartsWith("S")) // Student ID (assuming starts with 'S')
                    {
                        int studentId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'S' prefix
                        bool isDeleted = await DeleteStudentAsync(studentId);
                        if (isDeleted)
                        {
                            MessageBox.Show("Student deleted successfully.");
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete student.");
                        }
                    }
                    // Check if ID is for Admin (ID starts with 'A')
                    else if (txtTeacher.Text.StartsWith("A")) // Admin ID (assuming starts with 'A')
                    {
                        int adminId = int.Parse(txtTeacher.Text.Substring(1)); // Remove 'A' prefix

                        // Call DeleteAdminAsync to delete the Admin from the API
                        bool isDeleted = await DeleteAdminAsync(adminId);
                        if (isDeleted)
                        {
                            MessageBox.Show("Admin deleted successfully.");
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete admin.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid ID format. Ensure the Admin ID starts with 'A'.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting: {ex.Message}");
                }


            }
        }
        
        private async void btnList_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter a valid ID.");
                return;
            }

            // Check if the ID is for a Teacher, Student, or Admin (can be done based on ID format or external logic)
            if (txtID.Text.StartsWith("T"))  // Assuming Teacher IDs start with 'T'
            {
                var teachers = await FetchAllTeachersAsync();
                if (teachers != null && teachers.Count > 0)
                {
                    PopulateTeachersList(teachers);
                    txtID.Clear();
                }
                else
                {
                    MessageBox.Show("No teachers found.");
                }
            }
            else if (txtID.Text.StartsWith("S"))  // Assuming Student IDs start with 'S'
            {
                var students = await FetchAllStudentsAsync();
                if (students != null && students.Count > 0)
                {
                    PopulateStudentsList(students);
                    txtID.Clear();
                }
                else
                {
                    MessageBox.Show("No students found.");
                }
            }
            else if (txtID.Text.StartsWith("A"))  // Assuming Admin IDs start with 'A'
            {
                var admins = await FetchAllAdminsAsync();
                if (admins != null && admins.Count > 0)
                {
                    PopulateAdminsList(admins);
                    txtID.Clear();
                }
                else
                {
                    MessageBox.Show("No admins found.");
                }
            }
            else
            {
                MessageBox.Show("Invalid ID format.");
            }
        }

        private void btnUpdateAcc_Click(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            adminForm.Show();
            this.Hide();
        }

        private void btnViewGrades_Click(object sender, EventArgs e)
        {

        }

        private void btnInput_Click(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnAssignedStudent_Click(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse1 = new AssignedCourse1();
            assignedCourse1.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UpdateTeacher updateTeacher = new UpdateTeacher();
            updateTeacher.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            UpdateStudent updateStudent = new UpdateStudent();
            updateStudent.Show();
            this.Hide();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
