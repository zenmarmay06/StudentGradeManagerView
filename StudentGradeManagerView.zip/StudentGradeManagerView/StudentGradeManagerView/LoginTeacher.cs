﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;

namespace StudentGradeManagerView
{
    public partial class LoginTeacher : Form
    {
        public LoginTeacher()
        {
            InitializeComponent();
        }

        private void linkSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateTeacher createTeacher = new CreateTeacher();
            createTeacher.Show();
            this.Hide();
        }

        private async Task<bool> LoginTeacherAsync(Person model)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Login/");

                try
                {
                    // Send POST request to login as admin
                    HttpResponseMessage response = await client.PostAsJsonAsync("login/teacher", model);

                    if (response.IsSuccessStatusCode)
                    {
                        // Deserialize response content using JsonConvert
                        string jsonString = await response.Content.ReadAsStringAsync();
                        var result = JsonConvert.DeserializeObject<dynamic>(jsonString);

                        // Assuming the response includes the Token and Message
                        MessageBox.Show($"Login successful. ");
                        return true;
                    }
                    else
                    {
                        var errorMessage = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Error: {errorMessage}");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                    return false;
                }
            }
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            // Collect data from the form (example: TextBoxes)
            var teacher = new Person
            {
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                Platform = txtPlatform.Text
            };

            // Validate fields
            if (string.IsNullOrEmpty(teacher.Email) || string.IsNullOrEmpty(teacher.Password))
            {
                MessageBox.Show("Please fill in both email and password.");
                return;
            }

            // Call the LoginAdminAsync method
            bool success = await LoginTeacherAsync(teacher);

            if (success)
            {
                // You can clear the form or navigate away after successful login
                txtEmail.Clear();
                txtPassword.Clear();
                txtPlatform.Clear();
                UpdateTeacher updateTeacher = new UpdateTeacher();
                updateTeacher.Show();
                this.Hide();
            }
        }

        private void LoginTeacher_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShow.Checked)
            {
                txtPassword.PasswordChar = '\0'; // Show the actual password
            }
            else
            {
                txtPassword.PasswordChar = '*';  // Hide the password as '*'
            }
        }
    }
}
