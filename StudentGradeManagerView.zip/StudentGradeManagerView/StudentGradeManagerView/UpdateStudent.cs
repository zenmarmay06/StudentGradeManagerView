﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;

namespace StudentGradeManagerView
{
    public partial class UpdateStudent : Form
    {
        public UpdateStudent()
        {
            InitializeComponent();
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            StudentForm courselist = new StudentForm();
            courselist.Show();
            this.Hide();
        }

        private void btnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateStudent update = new UpdateStudent();
            update.Show();
            this.Hide();
        }

        private void btnView_Click(object sender, EventArgs e)
        {

            ViewStudent view = new ViewStudent();
            view.Show();
            this.Hide();
        }
        private async Task<Student> FetchStudentByIdAsync(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Student/Students"); // Replace with your actual API URL
                HttpResponseMessage response = await client.GetAsync($"Students/{id}");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<Student>(jsonString);
                }
                else
                {
                    MessageBox.Show("Student not found.");
                    return null;
                }
            }
        }

        private async Task<bool> UpdateStudentAsync(Student updatedStudent)
        {
            try
            {
                // Serialize the updatedTeacher object to JSON
                string json = JsonConvert.SerializeObject(updatedStudent);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44330/api/Student/Students");

                    // Make a PUT request to update the teacher by TeacherID
                    HttpResponseMessage response = await client.PutAsync($"{updatedStudent.StudentID}", content);

                    if (response.IsSuccessStatusCode)
                    {
                        return true; // Update was successful
                    }
                    else
                    {
                        // Log response details for debugging
                        string responseContent = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to update student.\nStatus Code: {response.StatusCode}\nResponse: {responseContent}");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle and log unexpected errors
                MessageBox.Show($"Error updating student: {ex.Message}");
                return false;
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate and parse the Teacher ID
                if (!int.TryParse(txtStudent.Text, out int studentId))
                {
                    MessageBox.Show("Invalid Student ID. Please enter a valid numeric ID.");
                    return;
                }

                // Create an updated Teacher object from the UI fields
                var updatedStudent = new Student
                {
                    StudentID = studentId,
                    Name = txtFullName.Text,
                    Email = txtEmail.Text,
                    Password = txtPassword.Text, // Password is entered by the user
                    YearSection = txtYearSection.Text
                };

                // Call the async method to update the Teacher in the API
                bool isUpdated = await UpdateStudentAsync(updatedStudent);
                if (isUpdated)
                {
                    MessageBox.Show("Student updated successfully.");
                    // Clear the fields after a successful update
                    lblStudentID.ResetText();
                    txtStudent.Clear();
                    txtFullName.Clear();
                    txtEmail.Clear();
                    txtPassword.Clear();
                    txtYearSection.Clear();
                }
                else
                {
                    MessageBox.Show("Failed to update student.");
                }
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtStudent.Text, out int studentId))
            {
                var student = await FetchStudentByIdAsync(studentId);
                if (student != null)
                {
                    lblStudentID.Text = student.StudentID.ToString();
                    txtFullName.Text = student.Name;
                    txtEmail.Text = student.Email;
                    txtPassword.Text = student.Password;
                    txtYearSection.Text = student.YearSection;
                }
                else
                {
                    MessageBox.Show("Student not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Student ID.");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }
    }
}
