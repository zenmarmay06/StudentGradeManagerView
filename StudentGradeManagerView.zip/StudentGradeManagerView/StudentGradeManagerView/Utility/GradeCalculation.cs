﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Utility
{
    public static class GradeCalculation
    {
        public static double CalculateFinalAverage(double? midtermGrade, double? finalGrade)
        {
            if (midtermGrade > 0 && finalGrade > 0)
            {
                // Both grades exist, return their average
                return (midtermGrade.Value + finalGrade.Value) / 2;
            }
            else if (midtermGrade == 0 && finalGrade > 0)
            {
                // Only midterm grade exists
                return finalGrade.Value;
            }
            else if (finalGrade == 0 && midtermGrade > 0)
            {
                // Only final grade exists
                return midtermGrade.Value;
            }

            // No grades provided, return default value (e.g., 0)
            return 0;
        }

    }
}
