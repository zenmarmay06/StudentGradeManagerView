﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using StudentGradeManagerView.Store;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;

namespace StudentGradeManagerView
{
    public partial class AssignedCourse : Form
    {
        public object[] CourseID { get; private set; }
        public object CourseName { get; private set; }
        public object Semester { get; private set; }
        public object StudentName { get; private set; }
        public object MidtermGrade { get; private set; }
        public object FinalGrade { get; private set; }

        public AssignedCourse()
        {
            InitializeComponent();
            
        }
        

        
        public async Task GetAssignedCourses(int teacherId)
        {
            string apiUrl = "https://localhost:44330/api/Teacher/" + teacherId;
            using (var client = new HttpClient())
            {
                try
                {
                    // Send GET request and get the response
                    var response = await client.GetAsync(apiUrl);

                    // Log the status code for debugging
                    MessageBox.Show("Successfully fetch.");

                    // If status code is not OK (200), display an error message
                    if (!response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Failed to fetch data. Status code: " + response.StatusCode);
                        return;
                    }

                    // Read the response content as string
                    var responseContent = await response.Content.ReadAsStringAsync();

                    // Log the raw response content for debugging
                    //MessageBox.Show("Raw API Response: " + responseContent);

                    // Deserialize the JSON response to a List of CourseAssignments (or directly to your model)
                    var courses = JsonConvert.DeserializeObject<List<CourseAssignment>>(responseContent);

                    // Check if the courses list is null or empty
                    if (courses == null || courses.Count == 0)
                    {
                        MessageBox.Show("No courses found for this teacher.");
                        return;
                    }

                    // Bind the deserialized data to the DataGridView
                    dgvTeacher.DataSource = courses; // Directly bind the courses list
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("Error fetching data: " + ex.Message);
                }

            }
        }

        private async void btnSearch_Click_1(object sender, EventArgs e)
        {
            int teacherId = int.Parse(txtTeacher.Text); // Assuming txtTeacherId is where the Teacher ID is entered
            await GetAssignedCourses(teacherId);
        }

        private void btnUpdateAcc_Click(object sender, EventArgs e)
        {
            UpdateTeacher teacher = new UpdateTeacher();
            teacher.Show();
            this.Hide();
        }

        private void btnAssignedStudent_Click(object sender, EventArgs e)
        {
            AssignedCourse ass = new AssignedCourse();
            ass.Show();
            this.Hide();
        }

        private void btnInput_Click(object sender, EventArgs e)
        {
            InputGrades inputGrades = new InputGrades();
            inputGrades.Show();
            this.Hide();
        }

        private void btnCourseList_Click(object sender, EventArgs e)
        {
            CourseList courseList = new CourseList();
            courseList.Show();
            this.Hide();
        }

        private void btnCourseAssigned_Click(object sender, EventArgs e)
        {
            AssignedCourse1 assignedCourse1 = new AssignedCourse1();
            assignedCourse1.Show();
            this.Hide();
        }

        private void btnViewGrades_Click(object sender, EventArgs e)
        {
            ViewTeacher viewTeacher = new ViewTeacher();
            viewTeacher.Show();
            this.Hide();
        }

        private void txtTeacher_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Show a confirmation message box
            DialogResult result = MessageBox.Show("Are you sure you want to log out?",
                                                  "Logout Confirmation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            // If the user clicks "Yes", proceed with logout
            if (result == DialogResult.Yes)
            {
                // Show the login form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the current form
                this.Close();
            }
        }
    }
}
