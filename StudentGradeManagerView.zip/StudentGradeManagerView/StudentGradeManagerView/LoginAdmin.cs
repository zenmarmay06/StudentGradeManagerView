﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using StudentGradeManagerView.Model;

namespace StudentGradeManagerView
{
    public partial class LoginAdmin : Form
    {
        public LoginAdmin()
        {
            InitializeComponent();
        }

        private void linkSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CreateAdmin createAdmin  = new CreateAdmin();
            createAdmin.Show();
            this.Hide();
        }

        private async Task<bool> LoginAdminAsync(Person model)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44330/api/Login/");

                try
                {
                    // Send POST request to login as admin
                    HttpResponseMessage response = await client.PostAsJsonAsync("login/admin", model);

                    if (response.IsSuccessStatusCode)
                    {
                        // Deserialize response content using JsonConvert
                        string jsonString = await response.Content.ReadAsStringAsync();
                        var result = JsonConvert.DeserializeObject<dynamic>(jsonString);

                        // Assuming the response includes the Token and Message
                        MessageBox.Show($"Login successful. ");
                        return true;
                        
                    }
                    else
                    {
                        var errorMessage = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Error: {errorMessage}");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                    return false;
                }
            }
        }


        private async void btnLogin_Click(object sender, EventArgs e)
        {
            // Collect data from the form (example: TextBoxes)
            var admin = new Person
            {
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                Platform = txtPlatform.Text
            };

            // Validate fields
            if (string.IsNullOrEmpty(admin.Email) || string.IsNullOrEmpty(admin.Password))
            {
                MessageBox.Show("Please fill in both email and password.");
                return;
            }

            // Call the LoginAdminAsync method
            bool success = await LoginAdminAsync(admin);

            if (success)
            {
                // You can clear the form or navigate away after successful login
                txtEmail.Clear();
                txtPassword.Clear();
                txtPlatform.Clear();
                AdminForm adminForm = new AdminForm();
                adminForm.Show();
                this.Hide();
            }
        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShow.Checked)
            {
                txtPassword.PasswordChar = '\0'; // Show the actual password
            }
            else
            {
                txtPassword.PasswordChar = '*';  // Hide the password as '*'
            }
        }

        private void LoginAdmin_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }
    }
}
