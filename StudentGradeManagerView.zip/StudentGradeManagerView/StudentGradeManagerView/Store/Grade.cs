﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Store
{
    public class Grade
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public double MidtermGrade { get; set; }
        public double FinalGrade { get; set; }
        public double FinalAverage { get; set; }
    }
}
