﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Store
{
    public class CourseAssignment1
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; } // New property for course name
        public int StudentID { get; set; }
        public string Semester { get; set; }  // Track semester assignment (e.g., "first" or "second")
        public string StudentName { get; set; }


    }
}
