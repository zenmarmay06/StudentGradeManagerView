﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeManagerView.Store
{
  
        public class CourseAssignmentDetails
        {
            public int CourseID { get; set; }
            public string CourseName { get; set; }
            public string Semester { get; set; }
            public int StudentID { get; set; }
            public string StudentName { get; set; }
            public float? MidtermGrade { get; set; }
            public float? FinalGrade { get; set; }
        }

        public class TeacherWithAssignments
        {
            public string Teacher { get; set; } // Teacher's Name
            public List<CourseAssignmentDetails> AssignedCourses { get; set; }
        }

    
}
